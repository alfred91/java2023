package calcular;
public class Calaculadora {

	public boolean esPar(int a) {
		return a % 2 == 0;
	}

	public int suma(int a, int b){
		return a+ b;
	}
}
