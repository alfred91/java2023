package cajita;

public class Caja {
	private static int numCajas;
	private int capacidadMaxima;
	private int cantidadActual;
	

	public Caja(){
	this(500, 0);
}

public Caja(int capacidadMax){
	this(capacidadMax,capacidadMax);
}

public Caja(int capacidadMax, int cantidadActual){
	this.capacidadMaxima = capacidadMax;
	this.cantidadActual = cantidadActual;
	if(cantidadActual > capacidadMax){
		this.cantidadActual = capacidadMax;
	}
	numCajas++;
}

public int getCapacidadMaxima() {
	return capacidadMaxima;
}

public int getCantidadActual() {
	return cantidadActual;
}

public void llenarCaja(){
	this.cantidadActual = this.capacidadMaxima;
}

public void sacarMonedas(int cantidadMonedas){
	if(cantidadMonedas > this.cantidadActual){
		vaciarCaja();
	}
	else{
		this.cantidadActual = this.cantidadActual - cantidadMonedas;
	}

}

public void vaciarCaja(){
	this.cantidadActual = 0;
}

public void agregarMonedas(int cantidad){
	if (this.cantidadActual + cantidad > this.capacidadMaxima){
		llenarCaja();
	}
	else{
		this.cantidadActual = this.cantidadActual + cantidad;
	}
}

public static int getNumeroCajas() {
	return numCajas;
}
}
